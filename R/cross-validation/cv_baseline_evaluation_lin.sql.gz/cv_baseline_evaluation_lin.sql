drop table if exists  madlibtestdata.evaluation_general_cv_lin;
create table madlibtestdata.evaluation_general_cv_lin (
    source          text,
    dataset         text,
    fold            integer,
    error           double precision
);

alter table madlibtestdata.evaluation_general_cv_lin owner to madlibtester;

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_concrete_wi', 10,
    14.6832686301684);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_auto_mpg_wi', 10,
    11.4035523107801);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_communities_wi', 10,
    0.0469415544546407);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_flare_wi', 10,
    0.0104408327190495);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_forestfires_wi', 10,
    4090.68221370257);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_housing_wi', 10,
    23.8551544793834);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_imports_85_wi', 10,
    17027330.8553092);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_machine_wi', 10,
    3159.34898751947);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_o_ring_erosion_only_wi', 10,
    0.18906148466027);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_o_ring_erosion_or_blowby_wi', 10,
    0.394202537947207);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_parkinsons_updrs_wi', 10,
    0.00189866668487564);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_servo_wi', 10,
    1.50972542240757);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_slump_wi', 10,
    7.70106597559226);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_winequality_red_wi', 10,
    0.425315372815003);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_winequality_white_wi', 10,
    0.569000026165975);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_Concrete_wi', 20,
    14.6711949197009);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_auto_mpg_wi', 20,
    11.3985378880764);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_communities_wi', 20,
    0.0433319183735778);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_flare_wi', 20,
    0.0104149417667294);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_forestfires_wi', 20,
    4073.48854657236);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_housing_wi', 20,
    23.7349172201294);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_imports_85_wi', 20,
    16907914.8182258);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_machine_wi', 20,
    3241.27487280615);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_o_ring_erosion_only_wi', 20,
    0.178998722260819);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_o_ring_erosion_or_blowby_wi', 20,
    0.367595511845735);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_parkinsons_updrs_wi', 20,
    0.00189779922313911);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_servo_wi', 20,
    1.5096031888672);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_slump_wi', 20,
    7.69889885932811);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_winequality_red_wi', 20,
    0.424979438146866);

insert into madlibtestdata.evaluation_general_cv_lin values
    ('R', 'lin_winequality_white_wi', 20,
    0.568730439475429);

