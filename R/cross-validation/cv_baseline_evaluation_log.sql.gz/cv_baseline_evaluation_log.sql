drop table if exists  madlibtestdata.evaluation_general_cv_log;
create table madlibtestdata.evaluation_general_cv_log (
    source          text,
    dataset         text,
    fold            integer,
    error           double precision
);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_breast_cancer_wisconsin', 10,
    0.967123188405797);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_ticdata2000', 10,
    0.937303095141259);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_wdbc', 10,
    0.946194862155389);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_wpbc', 10,
    0.783178947368421);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_breast_cancer_wisconsin', 20,
    0.967219327731092);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_ticdata2000', 20,
    0.937272607447159);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_wdbc', 20,
    0.940694581280788);

insert into madlibtestdata.evaluation_general_cv_log values
    ('R', 'log_wpbc', 20,
    0.788411111111111);

alter table madlibtestdata.evaluation_general_cv_log owner to madlibtester;

