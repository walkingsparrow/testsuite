drop table if exists  madlibtestdata.evaluation_lin_grouping;
create table madlibtestdata.evaluation_lin_grouping (
    source          text,
    dataset         text,
    grouping        text[],
    grouping_vals   integer[],
    hetero          boolean,
    coef            double precision[],
    r2              double precision,
    std_err         double precision[],
    t_stats         double precision[],
    p_values        double precision[],
    condition_no    double precision,
    bp_stats  double precision,
    bp_p_value    double precision,
    corrected_std_err  double precision[],
    corrected_t_stats  double precision[],
    corrected_p_values double precision[]
);

alter table madlibtestdata.evaluation_lin_grouping owner to madlibtester;

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{1}'::integer[],
    'True'::boolean,
    '{5.910169, 0.0006896029, 1.376057}'::double precision[],
    '0.62293286059696'::double precision,
    '{2.392676, 5.037106e-05, 0.3838585}'::double precision[],
    '{2.470108, 13.69046, 3.584802}'::double precision[],
    '{0.01498815, 8.007932e-26, 0.0004977992}'::double precision[],
    '52889.293981712'::double precision,
    '4.75377542053657'::double precision,
    '0.092839070426293'::double precision,
    '{2.18858, 6.373852e-05, 0.397893}'::double precision[],
    '{2.700458, 10.81925, 3.458359}'::double precision[],
    '{0.007980044, 3.375202e-19, 0.0007650413}'::double precision[]);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{2}'::integer[],
    'True'::boolean,
    '{11.58904, 0.0007754491, 0.09247755}'::double precision[],
    '0.0319925795907055'::double precision,
    '{7.731557, 0.001102837, 1.013933}'::double precision[],
    '{1.498927, 0.7031405, 0.0912068}'::double precision[],
    '{0.154642, 0.4927382, 0.9285351}'::double precision[],
    '10444.4166569812'::double precision,
    '4.82633826646307'::double precision,
    '0.0895311084871512'::double precision,
    '{6.645704, 0.001469104, 0.7644877}'::double precision[],
    '{1.74384, 0.5278382, 0.1209667}'::double precision[],
    '{0.1016389, 0.6053326, 0.905323}'::double precision[]);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{3}'::integer[],
    'True'::boolean,
    '{1.051101, 0.003729579, 0.4163978}'::double precision[],
    '0.451381842721041'::double precision,
    '{3.126017, 0.001298385, 0.446768}'::double precision[],
    '{0.336243, 2.872476, 0.9320224}'::double precision[],
    '{0.7416742, 0.01229247, 0.3671203}'::double precision[],
    '3987.33553225085'::double precision,
    '1.15861961464607'::double precision,
    '0.560284937706789'::double precision,
    '{1.927511, 0.001214062, 0.2403554}'::double precision[],
    '{0.5453154, 3.071984, 1.732425}'::double precision[],
    '{0.5941186, 0.008280482, 0.1051597}'::double precision[]);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{4}'::integer[],
    'True'::boolean,
    '{3.354344, 0.0008476459, 0.1935615}'::double precision[],
    '0.277236567983494'::double precision,
    '{1.712572, 0.0001508787, 0.2585514}'::double precision[],
    '{1.958659, 5.618064, 0.7486383}'::double precision[],
    '{0.05314857, 1.999803e-07, 0.4559644}'::double precision[],
    '14107.2937855526'::double precision,
    '47.5198675582853'::double precision,
    '4.79945439522563e-11'::double precision,
    '{1.469607, 0.0003041924, 0.2174306}'::double precision[],
    '{2.282476, 2.786545, 0.8902219}'::double precision[],
    '{0.02474057, 0.006457651, 0.3756439}'::double precision[]);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{1}'::integer[],
    'False'::boolean,
    '{5.910169, 0.0006896029, 1.376057}'::double precision[],
    '0.62293286059696'::double precision,
    '{2.392676, 5.037106e-05, 0.3838585}'::double precision[],
    '{2.470108, 13.69046, 3.584802}'::double precision[],
    '{0.01498815, 8.007932e-26, 0.0004977992}'::double precision[],
    '52889.293981712'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{2}'::integer[],
    'False'::boolean,
    '{11.58904, 0.0007754491, 0.09247755}'::double precision[],
    '0.0319925795907055'::double precision,
    '{7.731557, 0.001102837, 1.013933}'::double precision[],
    '{1.498927, 0.7031405, 0.0912068}'::double precision[],
    '{0.154642, 0.4927382, 0.9285351}'::double precision[],
    '10444.4166569812'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{3}'::integer[],
    'False'::boolean,
    '{1.051101, 0.003729579, 0.4163978}'::double precision[],
    '0.451381842721041'::double precision,
    '{3.126017, 0.001298385, 0.446768}'::double precision[],
    '{0.336243, 2.872476, 0.9320224}'::double precision[],
    '{0.7416742, 0.01229247, 0.3671203}'::double precision[],
    '3987.33553225085'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{nation}'::text[],
    '{4}'::integer[],
    'False'::boolean,
    '{3.354344, 0.0008476459, 0.1935615}'::double precision[],
    '0.277236567983494'::double precision,
    '{1.712572, 0.0001508787, 0.2585514}'::double precision[],
    '{1.958659, 5.618064, 0.7486383}'::double precision[],
    '{0.05314857, 1.999803e-07, 0.4559644}'::double precision[],
    '14107.2937855526'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{1, 1}'::integer[],
    'False'::boolean,
    '{9.790057, 0.0003370909}'::double precision[],
    '0.00883139357625472'::double precision,
    '{2.424068, 0.0007142269}'::double precision[],
    '{4.038688, 0.4719662}'::double precision[],
    '{0.0004485561, 0.6410445}'::double precision[],
    '4031.24200096242'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{2, 1}'::integer[],
    'False'::boolean,
    '{-1.156681, 0.0007253358}'::double precision[],
    '0.914233084559271'::double precision,
    '{8.263854, 9.069742e-05}'::double precision[],
    '{-0.1399687, 7.997315}'::double precision[],
    '{0.8932652, 0.0002038439}'::double precision[],
    '164546.301287086'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{3, 1}'::integer[],
    'False'::boolean,
    '{2, -1.981189e-18}'::double precision[],
    Null::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1467.52928703685'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{4, 1}'::integer[],
    'False'::boolean,
    '{13.40036, 0.0009264991}'::double precision[],
    '0.351692579261086'::double precision,
    '{5.497628, 0.0003247942}'::double precision[],
    '{2.43748, 2.852573}'::double precision[],
    '{0.0277143, 0.01210333}'::double precision[],
    '32735.0412699145'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{5, 1}'::integer[],
    'False'::boolean,
    '{4.741894, 0.002737051}'::double precision[],
    '0.725902677565546'::double precision,
    '{4.826244, 0.000840942}'::double precision[],
    '{0.9825226, 3.254744}'::double precision[],
    '{0.3814702, 0.03123542}'::double precision[],
    '6913.37725544757'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{6, 1}'::integer[],
    'False'::boolean,
    '{7.106857, 0.002411574}'::double precision[],
    '0.298081239332302'::double precision,
    '{3.104913, 0.001068283}'::double precision[],
    '{2.288907, 2.257431}'::double precision[],
    '{0.0410125, 0.0434116}'::double precision[],
    '3280.49157404519'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{7, 1}'::integer[],
    'False'::boolean,
    '{9.036135, 0.001862924}'::double precision[],
    '0.0871754219715278'::double precision,
    '{4.427943, 0.001817588}'::double precision[],
    '{2.040707, 1.024943}'::double precision[],
    '{0.0660237, 0.3274019}'::double precision[],
    '3962.3484303454'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{8, 1}'::integer[],
    'False'::boolean,
    '{14.14006, 0.001961756}'::double precision[],
    '0.364242086498062'::double precision,
    '{5.791803, 0.0009795956}'::double precision[],
    '{2.441391, 2.002618}'::double precision[],
    '{0.04466769, 0.08528933}'::double precision[],
    '8591.5617902119'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{9, 1}'::integer[],
    'False'::boolean,
    '{11.30366, 0.001421897}'::double precision[],
    '0.634210270159084'::double precision,
    '{5.396879, 0.0003599531}'::double precision[],
    '{2.094481, 3.950228}'::double precision[],
    '{0.06570399, 0.003353553}'::double precision[],
    '18738.2330232206'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{10, 1}'::integer[],
    'False'::boolean,
    '{16.63467, 0.003317768}'::double precision[],
    '0.260211602441472'::double precision,
    '{7.322224, 0.001977841}'::double precision[],
    '{2.271805, 1.677469}'::double precision[],
    '{0.05274164, 0.131972}'::double precision[],
    '5561.00256963343'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{1, 2}'::integer[],
    'False'::boolean,
    '{29.21296, -0.003306878}'::double precision[],
    '1'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '17350.9271910434'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{3, 2}'::integer[],
    'False'::boolean,
    '{0.3799664, 0.004196978}'::double precision[],
    '1'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '4429.37806186758'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{4, 2}'::integer[],
    'False'::boolean,
    '{20, Null}'::double precision[],
    '0'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{6, 2}'::integer[],
    'False'::boolean,
    '{-1.775956, 0.005464481}'::double precision[],
    '1'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1987.38201048668'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{8, 2}'::integer[],
    'False'::boolean,
    '{20.58503, -0.0008169062}'::double precision[],
    '0.0508374771967392'::double precision,
    '{5.173196, 0.001247974}'::double precision[],
    '{3.97917, -0.654586}'::double precision[],
    '{0.004066413, 0.5310992}'::double precision[],
    '6102.14698232987'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{10, 2}'::integer[],
    'False'::boolean,
    '{0, Null}'::double precision[],
    '0'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{1, 3}'::integer[],
    'False'::boolean,
    '{1.934794, 0.002920634}'::double precision[],
    '0.883405955211763'::double precision,
    '{1.056193, 0.0007502745}'::double precision[],
    '{1.831856, 3.892754}'::double precision[],
    '{0.2084408, 0.06010322}'::double precision[],
    '2112.19502801446'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{3, 3}'::integer[],
    'False'::boolean,
    '{1, Null}'::double precision[],
    '0'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{6, 3}'::integer[],
    'False'::boolean,
    '{9.49645, 0.001046394}'::double precision[],
    '0.00942535251868062'::double precision,
    '{14.24481, 0.01072729}'::double precision[],
    '{0.6666603, 0.09754504}'::double precision[],
    '{0.6256687, 0.9380967}'::double precision[],
    '2462.74178017405'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{8, 3}'::integer[],
    'False'::boolean,
    '{5.267, 0.002979401}'::double precision[],
    '0.350531506251999'::double precision,
    '{4.464062, 0.00202775}'::double precision[],
    '{1.179867, 1.469314}'::double precision[],
    '{0.3034298, 0.2156818}'::double precision[],
    '3877.86955268307'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{10, 3}'::integer[],
    'False'::boolean,
    '{-1.555428, 0.007582118}'::double precision[],
    '0.917040518349629'::double precision,
    '{4.415538, 0.002280496}'::double precision[],
    '{-0.3522624, 3.324767}'::double precision[],
    '{0.784384, 0.1859985}'::double precision[],
    '3300.3537278243'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{1, 4}'::integer[],
    'False'::boolean,
    '{-0.03475341, 0.006181349}'::double precision[],
    '0.416631005810912'::double precision,
    '{1.836699, 0.002111488}'::double precision[],
    '{-0.01892167, 2.927485}'::double precision[],
    '{0.9852146, 0.012663}'::double precision[],
    '1347.35287746262'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{4, 4}'::integer[],
    'False'::boolean,
    '{-88.78829, 0.01342871}'::double precision[],
    '0.353821927986206'::double precision,
    '{98.07651, 0.01283226}'::double precision[],
    '{-0.9052962, 1.046481}'::double precision[],
    '{0.460862, 0.4051707}'::double precision[],
    '175932.453743932'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{5, 4}'::integer[],
    'False'::boolean,
    '{6, Null}'::double precision[],
    '0'::double precision,
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '{Null, Null}'::double precision[],
    '1'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{6, 4}'::integer[],
    'False'::boolean,
    '{3.180781, 0.001390473}'::double precision[],
    '0.269548615610216'::double precision,
    '{1.273639, 0.000440512}'::double precision[],
    '{2.497396, 3.156493}'::double precision[],
    '{0.01890614, 0.003901635}'::double precision[],
    '3453.41703995873'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{7, 4}'::integer[],
    'False'::boolean,
    '{2.983386, 0.001731235}'::double precision[],
    '0.314571356018467'::double precision,
    '{2.674987, 0.001142859}'::double precision[],
    '{1.11529, 1.514828}'::double precision[],
    '{0.3154408, 0.1902447}'::double precision[],
    '3168.18034910882'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{8, 4}'::integer[],
    'False'::boolean,
    '{5.355836, 0.0006799065}'::double precision[],
    '0.250455785342015'::double precision,
    '{1.808274, 0.0002263604}'::double precision[],
    '{2.961849, 3.003646}'::double precision[],
    '{0.006307687, 0.00569457}'::double precision[],
    '9879.82919079217'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{9, 4}'::integer[],
    'False'::boolean,
    '{10.23813, 0.0002489225}'::double precision[],
    '0.024023396340933'::double precision,
    '{4.314962, 0.0007095478}'::double precision[],
    '{2.372704, 0.3508185}'::double precision[],
    '{0.06373863, 0.7400218}'::double precision[],
    '12842.6620983054'::double precision,
    Null, Null,
    Null, Null, Null);

insert into madlibtestdata.evaluation_lin_grouping values (
    'R'::text,
    'lin_ornstein'::text,
    '{sector, nation}'::text[],
    '{10, 4}'::integer[],
    'False'::boolean,
    '{4.894746, 0.00125092}'::double precision[],
    '0.0440287798310137'::double precision,
    '{5.133054, 0.003365294}'::double precision[],
    '{0.9535738, 0.371712}'::double precision[],
    '{0.4106483, 0.7348093}'::double precision[],
    '3400.08940455973'::double precision,
    Null, Null,
    Null, Null, Null);

